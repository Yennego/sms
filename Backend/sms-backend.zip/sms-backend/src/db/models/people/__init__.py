from src.db.models.people.student import Student
from src.db.models.people.teacher import Teacher
from src.db.models.people.parent import Parent

__all__ = ['Student', 'Teacher', 'Parent']