from .student import student
from .teacher import teacher
from .parent import parent

__all__ = ["student", "teacher", "parent"]