from .resource import resource

__all__ = ["resource"]