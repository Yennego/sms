from .base import CRUDBase, TenantCRUDBase

__all__ = ["CRUDBase", "TenantCRUDBase"]