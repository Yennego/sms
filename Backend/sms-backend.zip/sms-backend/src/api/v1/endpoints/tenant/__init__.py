from .tenant import router

__all__ = ["router"]