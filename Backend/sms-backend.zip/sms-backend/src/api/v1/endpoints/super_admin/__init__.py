from .super_admin import router

__all__ = ["router"]