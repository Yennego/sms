from .resource import router

__all__ = ["router"]