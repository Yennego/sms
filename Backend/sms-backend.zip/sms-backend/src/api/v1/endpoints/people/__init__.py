from .people import router

__all__ = ["router"]